--
-- PostgreSQL database dump
--

\restrict QdciY6ExSPcoy7XiCgpJQTIS7rs1ZuTdhexR4CxpoA6GAlt8AV70GdGCjOVl72h

-- Dumped from database version 15.17 (Homebrew)
-- Dumped by pg_dump version 18.3 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: assistant
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO assistant;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: assistant
--

CREATE TABLE public.jobs (
    id uuid NOT NULL,
    kind character varying(64) DEFAULT 'task'::character varying NOT NULL,
    description text NOT NULL,
    status character varying(32) DEFAULT 'queued'::character varying NOT NULL,
    payload jsonb,
    result jsonb,
    error_message text,
    resolved_skill character varying(64),
    resolved_model character varying(64),
    resolved_effort character varying(16),
    user_rating smallint,
    review_outcome character varying(32),
    project_id uuid,
    schedule_id uuid,
    parent_job_id uuid,
    created_by character varying(64) DEFAULT 'unknown'::character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.jobs OWNER TO assistant;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: assistant
--

CREATE TABLE public.projects (
    id uuid NOT NULL,
    slug character varying(64) NOT NULL,
    subdomain character varying(128) NOT NULL,
    type character varying(16) NOT NULL,
    port integer,
    manifest_path character varying(512) NOT NULL,
    last_healthy_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    created_by_job_id uuid
);


ALTER TABLE public.projects OWNER TO assistant;

--
-- Name: schedules; Type: TABLE; Schema: public; Owner: assistant
--

CREATE TABLE public.schedules (
    id uuid NOT NULL,
    name character varying(128) NOT NULL,
    cron_expression character varying(128) NOT NULL,
    job_kind character varying(64) NOT NULL,
    job_description text NOT NULL,
    job_payload jsonb,
    project_id uuid,
    paused boolean DEFAULT false NOT NULL,
    next_run_at timestamp with time zone,
    last_run_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.schedules OWNER TO assistant;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: assistant
--

COPY public.alembic_version (version_num) FROM stdin;
001
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: assistant
--

COPY public.jobs (id, kind, description, status, payload, result, error_message, resolved_skill, resolved_model, resolved_effort, user_rating, review_outcome, project_id, schedule_id, parent_job_id, created_by, created_at, started_at, completed_at) FROM stdin;
1efefaf6-38f4-4d58-bd22-a4a83916f983	task	research the nba trade deadline and its impact on player props	failed	null	null	append() got multiple values for argument 'kind'	research-report	claude-sonnet-4-6	medium	\N	\N	\N	\N	\N	telegram:6632944089	2026-04-17 01:21:29.506694-04	2026-04-17 01:21:29.532412-04	2026-04-17 01:21:29.546192-04
192b4f6f-eefe-4066-a333-d2046c8f256e	chat	why did that task fail	failed	null	null	append() got multiple values for argument 'kind'	chat	claude-sonnet-4-6	medium	\N	\N	\N	\N	\N	telegram:6632944089	2026-04-17 01:33:34.173429-04	2026-04-17 01:33:34.191277-04	2026-04-17 01:33:34.200227-04
1f18866d-baf3-4bb5-a745-5d5604b0bbbd	chat	why did that task fail	failed	null	null	append() got multiple values for argument 'kind'	chat	claude-sonnet-4-6	medium	\N	\N	\N	\N	\N	telegram:6632944089	2026-04-17 01:33:34.321756-04	2026-04-17 01:33:34.329161-04	2026-04-17 01:33:34.335856-04
6685b12b-585c-4dcd-bf2b-b23f10e63400	chat	hello	completed	null	{"skill": "chat", "usage": {"speed": "standard", "iterations": [{"type": "message", "input_tokens": 3, "output_tokens": 12, "cache_creation": {"ephemeral_1h_input_tokens": 11013, "ephemeral_5m_input_tokens": 0}, "cache_read_input_tokens": 0, "cache_creation_input_tokens": 11013}], "input_tokens": 3, "service_tier": "standard", "inference_geo": "", "output_tokens": 12, "cache_creation": {"ephemeral_1h_input_tokens": 11013, "ephemeral_5m_input_tokens": 0}, "server_tool_use": {"web_fetch_requests": 0, "web_search_requests": 0}, "cache_read_input_tokens": 0, "cache_creation_input_tokens": 11013}, "summary": "Hello! How can I help you today?", "duration_seconds": 4.299617}	\N	chat	claude-sonnet-4-6	medium	5	\N	\N	\N	\N	telegram:6632944089	2026-04-17 10:53:52.10596-04	2026-04-17 10:53:52.134545-04	2026-04-17 10:53:56.448064-04
5fa43e5c-e6d5-4e08-ab33-d254a59e5f7f	task	research the nba trade deadline and its impact on player props	completed	null	{"skill": "research-report", "usage": {"speed": "standard", "iterations": [{"type": "message", "input_tokens": 1, "output_tokens": 1676, "cache_creation": {"ephemeral_1h_input_tokens": 2181, "ephemeral_5m_input_tokens": 0}, "cache_read_input_tokens": 16319, "cache_creation_input_tokens": 2181}], "input_tokens": 9, "service_tier": "standard", "inference_geo": "", "output_tokens": 2208, "cache_creation": {"ephemeral_1h_input_tokens": 8883, "ephemeral_5m_input_tokens": 0}, "server_tool_use": {"web_fetch_requests": 0, "web_search_requests": 0}, "cache_read_input_tokens": 62518, "cache_creation_input_tokens": 8883}, "summary": "Here's a comprehensive breakdown of the **2026 NBA Trade Deadline** and its ripple effects on **player props**:\\n\\n---\\n\\n## 🏀 2026 NBA Trade Deadline Overview\\n\\n- **Date:** February 5, 2026 (3 PM ET)\\n- **Scale:** A record-setting **28 deals** involving **73 players** — the most active deadline in NBA history\\n- **Key non-moves:** Giannis Antetokounmpo stayed in Milwaukee; Ja Morant stayed in Memphis\\n\\n---\\n\\n## 🔄 Major Trades & Player Prop Implications\\n\\n### 1. 🔵 James Harden → Cleveland Cavaliers (from Clippers)\\n**Darius Garland sent to LA**\\n\\n- **Harden (CLE):** Joins Donovan Mitchell, Evan Mobley, and Jarrett Allen. Averaged **25.4 PPG / 8.1 APG** through 44 games. Cleveland has gone **17-6 in his 23 games** — his assist prop (8+) is highly exploitable as he takes playmaking pressure off Mitchell.\\n- **Garland (LAC):** Now the clear #1 option alongside Kawhi Leonard. Averaging **21.8 PPG / 6.7 APG** and playing the best basketball of his career. Scoring and assists props are both trending up in LA.\\n- **Prop angle:** Books were slow to price up Garland's usage spike post-trade — a classic role-change edge for sharp bettors.\\n\\n---\\n\\n### 2. 🏚️ Anthony Davis → Washington Wizards (from Dallas Mavericks)\\n**Massive 8-player swap**\\n\\n- Davis (age 32, coming off injuries) lands on a rebuilding Wizards team with young talent like Alex Sarr, Tre Johnson, and Kyshawn George.\\n- **Prop angle:** On a weak Wizards roster, Davis will face fewer double-teams and inherit a massive usage share. Points, rebounds, and blocks props are all worth monitoring — but injury risk and reduced motivation are countervailing factors. Books may price him conservatively given his injury history.\\n\\n---\\n\\n### 3. 🟡 Kristaps Porziņģis → Golden State Warriors\\n**Jonathan Kuminga & Buddy Hield sent to Atlanta**\\n\\n- Porziņģis is averaging **16.8 PPG / 5.2 REB / 2.6 AST** in ~24 MPG. With Steph Curry nursing a knee injury, KP has spiked to **22.3 PPG / 6.7 REB / 3.3 APG** as the focal point.\\n- **Prop angle:** Monitor Curry's health closely — when Curry sits, Porziņģis's points and usage props jump significantly. This \\"injury replacement\\" angle is high-value.\\n\\n---\\n\\n### 4. 🍀 Nikola Vučević → Boston Celtics\\n**Anfernee Simons sent to Chicago**\\n\\n- Vučević is averaging **9.9 PPG / 6.9 REB** in ~21 minutes. Recovering from a fractured finger, he's finding his footing in a crowded frontcourt where Neemias Queta has also carved out minutes.\\n- **Prop angle:** With reduced minutes and role uncertainty, Vučević's props (especially rebounds) are volatile heading into the playoffs. He's a **fade candidate** unless his playing time stabilizes above 25 minutes.\\n\\n---\\n\\n### 5. 🏀 Ivica Zubac → Indiana Pacers\\n**Bennedict Mathurin, Isaiah Jackson, picks to Clippers**\\n\\n- Zubac gives Indiana a legitimate defensive anchor next to Tyrese Haliburton.\\n- **Prop angle:** Zubac's block and rebound props benefit from increased role. Mathurin in LA now competes with a crowded wing rotation — his prop lines likely drop.\\n\\n---\\n\\n## 📊 Why the Trade Deadline = Player Prop Value\\n\\n| Factor | Why It Matters for Props |\\n|---|---|\\n| **Slow market adjustment** | Books adjust spreads/totals faster than player props |\\n| **Usage shifts** | New stars on weak teams see usage spike; bench players on contenders lose minutes |\\n| **Rotation uncertainty** | Coaches take time to find new rotations — books price on projections, not reality |\\n| **Injury replacement** | KP on GSW, Harden on CLE are \\"step into a big role\\" scenarios |\\n| **Rebuilding team stars** | AD on WAS faces fewer double-teams; line value in points/blocks |\\n\\n---\\n\\n## 🎯 Key Takeaways for Props Bettors\\n\\n1. **Target role-gainers** — Garland (LAC), Harden (CLE), Porziņģis (GSW when Curry out)\\n2. **Fade role-losers** — Vučević (limited rotation), Mathurin (crowded Clippers wing)\\n3. **Monitor injury reports** — KP/GSW is entirely Curry-dependent\\n4. **Watch for line lag** — The first 2-4 weeks post-deadline are the richest window for prop value before markets fully calibrate\\n\\n---\\n\\nSources:\\n- [NBA Trade Tracker: Every Player Dealt at the 2026 Trade Deadline – SportsGrid](https://www.sportsgrid.com/nba/article/nba-trade-tracker-every-player-dealt-at-the-2026-trade-deadline)\\n- [Every NBA Trade Deadline Deal in 2026 – bet365](https://news.bet365.com/en-us/article/every-nba-trade-deadline-deal-in-2026/2026020420391353506)\\n- [2026 NBA Trade Deadline Recap – Hoops Rumors](https://www.hoopsrumors.com/2026/02/2026-nba-trade-deadline-recap.html)\\n- [Clippers trade James Harden to Cavaliers for Darius Garland – NBA.com](https://www.nba.com/news/james-harden-darius-garland-trade)\\n- [Anthony Davis traded to Wizards – NBA.com](https://www.nba.com/news/wizards-mavericks-anthony-davis-trade)\\n- [Nikola Vucevic returns for the Celtics – Boston Globe](https://www.bostonglobe.com/2026/04/05/sports/nikola-vucevic-celtics-playoffs/)\\n- [Bold NBA Predictions After the 2026 Trade Deadline – Bleacher Report](https://bleacherreport.com/articles/25392778-bold-nba-predictions-after-2026-trade-deadline)\\n- [Best NBA Player Props Today: Post-Trade Deadline Action – The Lines](https://www.thelines.com/best-nba-player-props-today-post-trade-deadline-action/)", "duration_seconds": 70.942369}	\N	research-report	claude-sonnet-4-6	medium	4	\N	\N	\N	\N	telegram:6632944089	2026-04-17 10:54:32.784621-04	2026-04-17 10:54:32.795451-04	2026-04-17 10:55:43.750145-04
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: assistant
--

COPY public.projects (id, slug, subdomain, type, port, manifest_path, last_healthy_at, created_at, created_by_job_id) FROM stdin;
dd0228d4-6412-415d-9cfb-b93bce9a486b	baseball-bingo	bingo.chrispiserchia.com	static	\N	/Users/alfredbot.ai.butler/Library/Application Support/ai-server/projects/baseball-bingo/manifest.yml	\N	2026-04-17 14:21:07.400053-04	\N
d27311d7-8401-48e8-b2e9-ce30752e345d	market-tracker	market-tracker.chrispiserchia.com	service	8787	/Users/alfredbot.ai.butler/Library/Application Support/ai-server/projects/market-tracker/manifest.yml	2026-04-17 14:53:19.263379-04	2026-04-17 14:25:10.708075-04	\N
\.


--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: assistant
--

COPY public.schedules (id, name, cron_expression, job_kind, job_description, job_payload, project_id, paused, next_run_at, last_run_at, created_at) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: assistant
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: assistant
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: assistant
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects projects_subdomain_key; Type: CONSTRAINT; Schema: public; Owner: assistant
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_subdomain_key UNIQUE (subdomain);


--
-- Name: schedules schedules_name_key; Type: CONSTRAINT; Schema: public; Owner: assistant
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_name_key UNIQUE (name);


--
-- Name: schedules schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: assistant
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- Name: ix_jobs_autotune; Type: INDEX; Schema: public; Owner: assistant
--

CREATE INDEX ix_jobs_autotune ON public.jobs USING btree (resolved_skill, resolved_model, resolved_effort, status);


--
-- Name: ix_jobs_created_at; Type: INDEX; Schema: public; Owner: assistant
--

CREATE INDEX ix_jobs_created_at ON public.jobs USING btree (created_at);


--
-- Name: ix_jobs_resolved_skill; Type: INDEX; Schema: public; Owner: assistant
--

CREATE INDEX ix_jobs_resolved_skill ON public.jobs USING btree (resolved_skill);


--
-- Name: ix_jobs_status; Type: INDEX; Schema: public; Owner: assistant
--

CREATE INDEX ix_jobs_status ON public.jobs USING btree (status);


--
-- Name: ix_projects_slug; Type: INDEX; Schema: public; Owner: assistant
--

CREATE UNIQUE INDEX ix_projects_slug ON public.projects USING btree (slug);


--
-- Name: ix_schedules_next_run_at; Type: INDEX; Schema: public; Owner: assistant
--

CREATE INDEX ix_schedules_next_run_at ON public.schedules USING btree (next_run_at);


--
-- Name: jobs jobs_parent_job_fk; Type: FK CONSTRAINT; Schema: public; Owner: assistant
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_parent_job_fk FOREIGN KEY (parent_job_id) REFERENCES public.jobs(id) ON DELETE SET NULL;


--
-- Name: jobs jobs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: assistant
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: jobs jobs_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: assistant
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.schedules(id) ON DELETE SET NULL;


--
-- Name: projects projects_created_by_job_fk; Type: FK CONSTRAINT; Schema: public; Owner: assistant
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_created_by_job_fk FOREIGN KEY (created_by_job_id) REFERENCES public.jobs(id) ON DELETE SET NULL;


--
-- Name: schedules schedules_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: assistant
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO assistant;


--
-- PostgreSQL database dump complete
--

\unrestrict QdciY6ExSPcoy7XiCgpJQTIS7rs1ZuTdhexR4CxpoA6GAlt8AV70GdGCjOVl72h

